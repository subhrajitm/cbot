import React, { useState } from 'react';
import { Menu, Copy, Upload, Send, Plus, RotateCcw, Wrench, Share2, Star, Bot, Mic, Paperclip, Settings, Zap, Clock, FileText } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  const menuItems = [
    { icon: Plus, text: 'New Chat Session' },
    { icon: RotateCcw, text: 'Reset Chat' },
    { icon: Wrench, text: 'Gsmart AI Tools' },
    { icon: Share2, text: 'Share Chat' },
    { icon: Star, text: 'Toggle Favourite' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex flex-col">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200/50 px-6 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Gsmart
            </h1>
            <p className="text-xs text-gray-500">AI Assistant</p>
          </div>
        </div>
        
        <div className="relative">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-all duration-200"
          >
            <Menu className="w-4 h-4" />
            <span className="text-sm font-medium">Menu</span>
          </button>
          
          {isMenuOpen && (
            <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-200/50 py-2 z-10 backdrop-blur-md">
              {menuItems.map((item, index) => (
                <button
                  key={index}
                  className="w-full px-4 py-2.5 text-left text-gray-700 hover:bg-blue-50 flex items-center space-x-3 transition-all duration-200 group"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <item.icon className="w-4 h-4 text-gray-500 group-hover:text-blue-600" />
                  <span className="text-sm">{item.text}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </header>

      {/* Main Chat Area */}
      <main className="flex-1 px-4 py-6 max-w-4xl mx-auto w-full">
        {/* Chat Messages */}
        <div className="mb-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl px-5 py-4 max-w-2xl shadow-sm border border-gray-200/50">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Bot className="w-4 h-4 text-blue-600" />
                  <p className="font-semibold text-gray-800">Gsmart AI</p>
                </div>
                <p className="text-gray-700 leading-relaxed text-sm">
                  I can answer any question in the documents I am provided. Answers may not be correct.
                </p>
              </div>
              <button className="flex-shrink-0 px-3 py-1.5 bg-white/80 text-gray-600 text-xs rounded-lg hover:bg-white transition-all duration-200 flex items-center space-x-1 shadow-sm border border-gray-200/50">
                <Copy className="w-3 h-3" />
                <span>Copy</span>
              </button>
            </div>
          </div>
        </div>

        {/* Suggested Prompt */}
        <div className="mb-6">
          <button className="bg-gradient-to-r from-blue-100 to-purple-100 hover:from-blue-200 hover:to-purple-200 text-blue-800 px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-200 shadow-sm border border-blue-200/50">
            Tell me an interesting fact about the data provided
          </button>
        </div>
      </main>

      {/* Input Area */}
      <div className="bg-white/90 backdrop-blur-md border-t border-gray-200/50 shadow-lg">
        {/* Quick Actions Bar */}
        <div className="max-w-4xl mx-auto px-4 py-2 border-b border-gray-100/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-xs text-gray-500">
                <Clock className="w-3 h-3" />
                <span>Last active: 2 min ago</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-gray-500">
                <FileText className="w-3 h-3" />
                <span>3 documents loaded</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all duration-200">
                <Settings className="w-3.5 h-3.5" />
              </button>
              <button className="p-1.5 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-all duration-200">
                <Zap className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Main Input Area */}
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-end space-x-3">
            {/* File Upload Area */}
            <div className="flex-shrink-0">
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-2.5 w-24 h-14 flex flex-col items-center justify-center text-center hover:border-blue-400 hover:bg-blue-50/50 transition-all duration-200 cursor-pointer group">
                <Upload className="w-3.5 h-3.5 text-gray-400 group-hover:text-blue-500 mb-0.5" />
                <p className="text-xs text-gray-500 group-hover:text-blue-600 font-medium">
                  Upload
                </p>
              </div>
            </div>

            {/* Message Input */}
            <div className="flex-1 relative">
              <div className="relative">
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Ask Gsmart AI anything..."
                  className="w-full border border-gray-300 rounded-xl px-4 py-2.5 pr-20 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white/90 backdrop-blur-sm shadow-sm transition-all duration-200 text-sm"
                  rows={1}
                />
                <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
                  <button className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all duration-200">
                    <Paperclip className="w-3.5 h-3.5" />
                  </button>
                  <button 
                    onClick={() => setIsRecording(!isRecording)}
                    className={`p-1.5 rounded-lg transition-all duration-200 ${
                      isRecording 
                        ? 'text-red-600 bg-red-50 animate-pulse' 
                        : 'text-gray-400 hover:text-red-600 hover:bg-red-50'
                    }`}
                  >
                    <Mic className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Send Button */}
            <div className="flex-shrink-0">
              <button 
                disabled={!message.trim()}
                className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-200 flex items-center space-x-2 shadow-lg ${
                  message.trim()
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white hover:shadow-xl transform hover:-translate-y-0.5'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                <Send className="w-4 h-4" />
                <span className="text-sm">Send</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;